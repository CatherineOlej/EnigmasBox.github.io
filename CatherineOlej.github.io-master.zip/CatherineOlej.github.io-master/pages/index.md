---
layout: home
title: Welcome! My name is Catherine Olejarczyk
permalink: /
section: home
intro_paragraph: |-
  ## IT Innovation and Design

  ![](/assets/img/uploads/me.jpg)
---
# **WHAT I DO**

I create dynamic websites and applications using a variation of programming languages. I challenge myself with each project in order to deliver the best quality in all my projects. My primary focus is to envision every clients primary goal and work beyond their expectations in accordance with their needs.
