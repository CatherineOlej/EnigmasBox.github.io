---
layout: page
title: About Me
permalink: /about
section: about
intro_paragraph: ''
---
Profound changes to the world of computer applications have created the need for a new kind of software development professional. My experience provides me with skills in graphic desgin, content creation, User Experience (UX), software development, marketing, and buisness models in order to design and market new and competitive softeware applications.
